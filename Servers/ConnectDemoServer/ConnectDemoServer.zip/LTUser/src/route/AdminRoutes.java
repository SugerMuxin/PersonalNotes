package route;

import com.jfinal.config.Routes;

public class AdminRoutes extends Routes {

	@Override
	public void config() {

	}

}
